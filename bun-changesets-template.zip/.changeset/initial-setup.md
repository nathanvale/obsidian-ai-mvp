---
"PACKAGE_NAME_HERE": patch
---

Bootstrap: add Bun + Changesets + Commitizen/Commitlint + CI/Release workflows.
